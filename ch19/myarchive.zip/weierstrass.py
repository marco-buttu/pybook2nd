print('Karl Wilhelm Theodor  Weierstrass')
